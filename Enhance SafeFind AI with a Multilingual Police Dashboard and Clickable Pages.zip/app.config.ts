export default {
  logoUrl: "https://dummyimage.com/256x256/0f1b3d/2fd3c0.png&text=SF"
};
